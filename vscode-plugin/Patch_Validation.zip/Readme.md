Steps to use the demo project:
1. Extract the archive containing the example project and the plugin.
2. Open VSCode and go to extensions.
3. Install the aifix4seccode-vscode-0.1.1.vsix, the latest version of the VSCode plugin from file in the VSCode extensions panel
4. Edit the Patch_validation.code-workspace workspace file: set settings attributes to the folder you want to use (substitute the beginning of absolute paths to your custom settings
5. Open the Patch_validation.code-workspace file in VSCode
6. Press Start Analysis to launch the plugin button on the bottom left corner
7. Enable View/Problems view
8. Click on analysis report panel /Problems view panel items
9. Click on the lightbulb icon on the open source code 
10. Select the patch you want to see (e.g. Arja, Human, TBar)
11. Navigate/Apply/Reject a patch and add a reasoning about your decision
12. Optional: Observe logged decision in new file generated/appended in the workspace (user_decisions.txt).
13. Optional: Compile or run unit tests if necessary.
14. Optional: You can revert your decision (logged) and select another candidate.